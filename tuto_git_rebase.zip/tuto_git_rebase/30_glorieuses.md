# Les 30 glorieuses

Les **Trente Glorieuses** désigne la période de forte croissance économique qu’a connue la grande majorité des pays développés, membres pour la plupart de l’Organisation de coopération et de développement économiques (OCDE), entre 1945 et 1973.

L’expression a été créée par Jean Fourastié1 en 1979 en rappel des Trois Glorieuses, journées révolutionnaires des 27, 28 et 29 juillet 1830 qui avaient fait chuter Charles X.

Les Trente Glorieuses furent une révolution, certes silencieuse, mais porteuse en réalité de changements économiques et sociaux majeurs, qui ont marqué le passage de l’Europe, quarante années après les États-Unis, à la société de consommation. Le cas de la France permet de saisir en particulier le sens du sous-titre du livre de J. Fourastié, la « Révolution invisible », mais la croissance est forte aussi en Allemagne, en Italie au Canada et au Japon, tirée à la fois par l'investissement et la consommation.

Après un début difficile, les vingt-huit ans qui séparent la fin de la Seconde Guerre mondiale, en 1945, du choc pétrolier de 1973 se caractérisent par :

+ la reconstruction économique de pays largement dévastés par la guerre ;
+ le retour vers une situation de plein emploi dans la grande majorité des pays ;
+ une croissance forte de la production industrielle (un accroissement annuel moyen de la production d'environ 5 %) ;
+ une expansion démographique importante (le baby boom) dans certains pays européens et nord-américains (particulièrement en France, en Allemagne de l'Ouest, aux États-Unis et au Canada).

La forte croissance étant facilitée quant à elle par un accès encore aisé aux énergies en général et aux énergies fossiles en particulier ; et par un rattrapage technologique (par rapport aux États-Unis) dans les pays dont le capital humain (niveau d’éducation et d’expérience des travailleurs) était important.
