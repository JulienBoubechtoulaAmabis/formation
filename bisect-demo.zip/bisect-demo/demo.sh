#! /bin/bash

echo KO
